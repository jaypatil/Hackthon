# Getting Started

1. Fork and clone this repo

1. Use `npm i` to install the necessary dependencies

1. Run the TypeScript compiler, watch for changes, start the server, and launch the browser by using `npm start`
