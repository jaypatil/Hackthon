
import { Marker } from './marker';
import { MARKERS } from './mock-markers';

import { Injectable } from 'angular2/core';
@Injectable()
export class MarkerService {

    getMarkers() {
        return Promise.resolve(MARKERS);
    }

    // See the "Take it slow" appendix
    getMarkersSlowly() {
        return new Promise<Marker[]>(resolve =>
            setTimeout(() => resolve(MARKERS), 2000) // 2 seconds
        );
    }
    getMarker(label: string) {
        return Promise.resolve(MARKERS).then(
            markers => markers.filter(marker => marker.label === label)[0]
        );
    }
}

/*
Copyright 2016 Google Inc. All Rights Reserved.
Use of this source code is governed by an MIT-style license that
can be found in the LICENSE file at http://angular.io/license
*/