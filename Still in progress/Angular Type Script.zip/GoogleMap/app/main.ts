import { bootstrap }    from 'angular2/platform/browser';
import { AppComponent } from './app.component';
import {ANGULAR2_GOOGLE_MAPS_PROVIDERS} from 'angular2-google-maps/core';

bootstrap(AppComponent, [ANGULAR2_GOOGLE_MAPS_PROVIDERS]);

/*
Copyright 2016 Google Inc. All Rights Reserved.
Use of this source code is governed by an MIT-style license that
can be found in the LICENSE file at http://angular.io/license
*/