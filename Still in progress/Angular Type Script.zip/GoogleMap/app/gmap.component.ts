import { Component, OnInit } from 'angular2/core';
import { Router } from 'angular2/router';

import {ANGULAR2_GOOGLE_MAPS_DIRECTIVES} from 'angular2-google-maps/core';

import { Marker } from './marker';
import { MarkerService } from './marker.service';

@Component({
    selector: 'my-app',
    directives: [ANGULAR2_GOOGLE_MAPS_DIRECTIVES], // this loads all angular2-google-maps directives in this component
    // the following line sets the height of the map - Important: if you don't set a height, you won't see a map!!
    styles: [`
    .sebm-google-map-container {
      height: 300px;
    }
  `],
    template: `
    <h1>My first angular-google-maps app!</h1>

    <!-- this creates a google map on the page with the given lat/lng from the component as the initial center of the map: -->

    <sebm-google-map [latitude]="lat" [longitude]="lng">
        
        <sebm-google-map-marker 
        *ngFor="#m of markers; #i = index"
        (markerClick)="clickedMarker(m.label, i)"
        [latitude]="m.lat"
        [longitude]="m.lng"
        [label]="m.label"
        [markerDraggable]="m.draggable"
        (dragEnd)="markerDragEnd(m, $event)"></sebm-google-map-marker>
    
    </sebm-google-map>
  `
})
export class GmapComponent implements OnInit {

    zoom: number = 8;
    markers: Marker[];
    // initial center position for the map
    lat: number = 51.673858;
    lng: number = 7.815982;

    clickedMarker(label: string, index: number) {
        window.alert(`clicked the marker: ${label || index}`)
        // this.markers.splice(index, 1);
    }

    markerDragEnd(m: Marker, $event: MouseEvent) {
        console.log('dragEnd', m, $event);
    }


    constructor(private _router: Router,
        private _markerService: MarkerService) {
    }
    
    getMarkers() {
        this._markerService.getMarkers().then(markers => this.markers = markers);
    }

    ngOnInit() {
        this.getMarkers();
    }

}