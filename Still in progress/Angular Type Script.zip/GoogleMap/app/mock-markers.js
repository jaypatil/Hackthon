System.register([], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var MARKERS;
    return {
        setters:[],
        execute: function() {
            exports_1("MARKERS", MARKERS = [
                {
                    lat: 51.673858,
                    lng: 7.815982,
                    label: 'A',
                    draggable: true
                },
                {
                    lat: 51.373858,
                    lng: 7.215982,
                    label: 'B',
                    draggable: false
                },
                {
                    lat: 51.723858,
                    lng: 7.895982,
                    label: 'C',
                    draggable: true
                }
            ]);
        }
    }
});
/*
Copyright 2016 Google Inc. All Rights Reserved.
Use of this source code is governed by an MIT-style license that
can be found in the LICENSE file at http://angular.io/license
*/ 
//# sourceMappingURL=mock-markers.js.map