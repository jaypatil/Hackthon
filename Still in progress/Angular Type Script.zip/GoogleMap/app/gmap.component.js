System.register(['angular2/core', 'angular2/router', 'angular2-google-maps/core', './marker.service'], function(exports_1, context_1) {
    "use strict";
    var __moduleName = context_1 && context_1.id;
    var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
        var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
        if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
        else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
        return c > 3 && r && Object.defineProperty(target, key, r), r;
    };
    var __metadata = (this && this.__metadata) || function (k, v) {
        if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
    };
    var core_1, router_1, core_2, marker_service_1;
    var GmapComponent;
    return {
        setters:[
            function (core_1_1) {
                core_1 = core_1_1;
            },
            function (router_1_1) {
                router_1 = router_1_1;
            },
            function (core_2_1) {
                core_2 = core_2_1;
            },
            function (marker_service_1_1) {
                marker_service_1 = marker_service_1_1;
            }],
        execute: function() {
            GmapComponent = (function () {
                function GmapComponent(_router, _markerService) {
                    this._router = _router;
                    this._markerService = _markerService;
                    this.zoom = 8;
                    // initial center position for the map
                    this.lat = 51.673858;
                    this.lng = 7.815982;
                }
                GmapComponent.prototype.clickedMarker = function (label, index) {
                    window.alert("clicked the marker: " + (label || index));
                    // this.markers.splice(index, 1);
                };
                GmapComponent.prototype.markerDragEnd = function (m, $event) {
                    console.log('dragEnd', m, $event);
                };
                GmapComponent.prototype.getMarkers = function () {
                    var _this = this;
                    this._markerService.getMarkers().then(function (markers) { return _this.markers = markers; });
                };
                GmapComponent.prototype.ngOnInit = function () {
                    this.getMarkers();
                };
                GmapComponent = __decorate([
                    core_1.Component({
                        selector: 'my-app',
                        directives: [core_2.ANGULAR2_GOOGLE_MAPS_DIRECTIVES],
                        // the following line sets the height of the map - Important: if you don't set a height, you won't see a map!!
                        styles: ["\n    .sebm-google-map-container {\n      height: 300px;\n    }\n  "],
                        template: "\n    <h1>My first angular-google-maps app!</h1>\n\n    <!-- this creates a google map on the page with the given lat/lng from the component as the initial center of the map: -->\n\n    <sebm-google-map [latitude]=\"lat\" [longitude]=\"lng\">\n        \n        <sebm-google-map-marker \n        *ngFor=\"#m of markers; #i = index\"\n        (markerClick)=\"clickedMarker(m.label, i)\"\n        [latitude]=\"m.lat\"\n        [longitude]=\"m.lng\"\n        [label]=\"m.label\"\n        [markerDraggable]=\"m.draggable\"\n        (dragEnd)=\"markerDragEnd(m, $event)\"></sebm-google-map-marker>\n    \n    </sebm-google-map>\n  "
                    }), 
                    __metadata('design:paramtypes', [router_1.Router, marker_service_1.MarkerService])
                ], GmapComponent);
                return GmapComponent;
            }());
            exports_1("GmapComponent", GmapComponent);
        }
    }
});
//# sourceMappingURL=gmap.component.js.map